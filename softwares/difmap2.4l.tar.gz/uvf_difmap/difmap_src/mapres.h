float *mapres(Observation *ob, MapBeam *mb, Model *mod, float *clnmp,
	      float bmaj, float bmin, float bpa, int dosub, int noresid,
	      int dosmth, float freq);

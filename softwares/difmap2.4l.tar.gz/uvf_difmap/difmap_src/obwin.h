#ifndef obwin_h
#define obwin_h

int obwinmod(Observation *ob, Mapwin *mw, int doout);

#endif

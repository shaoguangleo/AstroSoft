printf("Caltech difference mapping program - version 2.4l (17 Apr 2010)\n");

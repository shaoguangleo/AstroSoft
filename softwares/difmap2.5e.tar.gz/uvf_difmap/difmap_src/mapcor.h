#ifndef mapcor_h
#define mapcor_h

int pb_cor_map(Observation *ob, MapBeam *mb, float cutoff);

#endif

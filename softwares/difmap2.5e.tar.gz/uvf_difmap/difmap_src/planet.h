#ifndef planet_h
#define planet_h

int planet_geometry(const char *name, double tt, double *ra, double *dec,
		    float *diam, float *flat);

#endif

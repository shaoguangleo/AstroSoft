printf("Caltech difference mapping program - version 2.5e (30 May 2019)\n");

Model *win_mod(Model *mod, Mapwin *wins, int docomp);
